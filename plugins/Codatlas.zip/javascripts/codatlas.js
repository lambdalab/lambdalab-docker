/*
 * This file is the entry point of the whole Chrome Codatlas plugin.
 */
requirejs.config(requirejsConfig);

requirejs([
  'GithubExplorerObserver',
  'actions/CodatlasActions',
  'jsx!GithubPageInjector'
],
function(GithubExplorerObserver,
         CodatlasActions,
         GithubPageInjector) {
  /*
   * @constructor
   */
  var apply_ = function() {
    // 1. Render all the components.
    GithubPageInjector.Apply();

    // Entry points:
    // 1. Browser refreshed, trigger the url change action.
    CodatlasActions.changeUrl();
    // 2. Content refreshed via ajax.
    // Register content mutate observer to detect ajax refresh. Trigger the url change action.
    GithubExplorerObserver.apply(function() {
      CodatlasActions.changeUrl();
    });
  };

  apply_();
});
