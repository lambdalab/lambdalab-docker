define(['JSXTransformer', 'text'], function (JSXTransformer, text) {

  'use strict';

  var buildMap = {};
  var jsx = {
    version: '0.5.2',

    load: function (name, req, onLoadNative, config) {
      var jsxOptions = config.jsx || {};
      var fileExtension = jsxOptions.fileExtension || '.js';

      // change the url to load jsx from chrome extension
      if (config.baseUrl.lastIndexOf("chrome-extension://", 0) !== 0) {
        config.baseUrl = chrome.extension.getURL(config.baseUrl);
      }

      var transformOptions = {
        harmony: !!jsxOptions.harmony,
        stripTypes: !!jsxOptions.stripTypes
      };

      var onLoad = function(content) {
        try {
          content = JSXTransformer.transform(content, transformOptions).code;
        } catch (err) {
          onLoadNative.error(err);
        }
        if (config.isBuild) {
          buildMap[name] = content;
        } else if (typeof location !== 'undefined') { // Do not create sourcemap when loaded in Node
          content += '\n//# sourceURL=' + config.baseUrl + name + fileExtension;
        }

        onLoadNative.fromText(content);
      };

      onLoad.error = function(err) {
        onLoadNative.error(err);
      };

      text.load(name + fileExtension, req, onLoad, config);
    },

    write: function (pluginName, moduleName, write) {
      if (buildMap.hasOwnProperty(moduleName)) {
        var content = buildMap[moduleName];
        write.asModule(pluginName + '!' + moduleName, content);
      }
    }
  };

  return jsx;
});
