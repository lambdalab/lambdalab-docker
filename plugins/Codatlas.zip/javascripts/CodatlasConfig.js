var codatlasServerConfig = {};

chrome.storage.sync.get({
  protocol: 'https',
  host: "www.codatlas.com",
  port: ""
}, function(items) {
  codatlasServerConfig.protocol = items.protocol;
  codatlasServerConfig.host = items.host;
  codatlasServerConfig.port = items.port;
});

console.log(codatlasServerConfig);