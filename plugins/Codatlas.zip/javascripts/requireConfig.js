var requirejsConfig = {
  /*
   * Load javascript modules within Chrome's domain.
   */
  //baseUrl: chrome.extension.getURL("/javascripts/modules/"),
  baseUrl: "javascripts/modules/",

  paths: {
    jquery: '/lib/jquery/dist/jquery',
    JSXTransformer : "/lib/jsx-requirejs-plugin/js/JSXTransformer",
    jsx : "/javascripts/jsx",  // use a modified version of 'jsx' to correctly load jsx files into chrome.
    lib: '/lib',
    react : "/lib/react/react.min",
    reactdom: "/lib/react/react-dom.min",
    reactdomserver: "/lib/react/react-dom-server.min",
    text : "/lib/requirejs-text/text",
    underscore: '/lib/underscore/underscore',
    uri: '/lib/uri.js/src',
    interact: '/lib/interact/interact',
    eventEmitter: '/lib/eventEmitter/EventEmitter',
    jstree: '/lib/jstree/dist/jstree',
    jqueryui: '/lib/jquery-ui/jquery-ui',
    jquerycookie: '/lib/jquery.cookie/jquery.cookie',
    string: '/lib/string/dist/string.min',
    mousetrap: '/lib/mousetrap/mousetrap.min',
    slidebars: 'javascripts/modules/utils/Slidebars'
  },

  /*
   * For jquery plugin dependency.
   */
  //shim: {
  //  'lib/notify': {
  //    deps: ['jquery']
  //  },
  //  'lib/bootstrap': {
  //    deps: ['jquery']
  //  },
  //  'lib/uri': {
  //    deps: ['jquery']
  //  }
  //}

  jsx: {
    fileExtension: '.jsx'
  }
};
