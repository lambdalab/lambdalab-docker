var CONNECTION_NAME = "Codatlas";

// Listen to Codatlas proxy connection request.
chrome.runtime.onConnect.addListener(function(port) {
  console.assert(port.name === CONNECTION_NAME);
  port.onMessage.addListener(function(msg) {
    console.log(msg);
    $.ajax({
      type: msg.type,
      url: msg.url,
      success: function(data) {
        var response = $.extend({response: data, success: true}, msg);
        port.postMessage(response);
      },
      error: function() {
        var response = $.extend({success: false}, msg);
        port.postMessage(response);
      }
    });
  });
});