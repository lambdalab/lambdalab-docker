var CodatlasProxyClient = function() {
  var CODATLAS_PROXY_CONNECTION_NAME = "Codatlas";

  var port_ = chrome.runtime.connect({name: CODATLAS_PROXY_CONNECTION_NAME});

  var requestsMap_ = [];

  port_.onMessage.addListener(function(msg) {
    if (requestsMap_[msg.id] === undefined) {
      console.error("Failed to found pending request with id " + msg.id);
      return;
    }
    var originalRequest = requestsMap_[msg.id];
    if (msg.success === undefined) {
      console.error("Unrecognized status of response");
      return;
    } else if (msg.success) {
      originalRequest.success(msg.response);
    } else {
      originalRequest.error();
    }
    delete requestsMap_[msg.id];
  });

  var query_ = function(request) {
    var queryId = queryId_(request);
    var newRequest = $.extend({id: queryId}, request);
    requestsMap_[queryId] = newRequest;
    port_.postMessage(newRequest);
  };

  var queryId_ = function(request) {
    return Date.now() + "-" + request.url;
  };

  return {
    Query: query_
  };
}();
