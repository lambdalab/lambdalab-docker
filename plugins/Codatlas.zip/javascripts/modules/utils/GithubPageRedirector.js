define(function(require) {
  var URI = require('uri/URI');
  function prepareJumpToData(targetNode, projectContext) {
    var targetNodeWihtinProject = false;
    var targetNodeWithinFile = false;

    if (targetNode.file_loc === undefined) {
      // for structure tree item and annotation
      targetNodeWihtinProject = true;
      targetNodeWithinFile = true;
    } else {
      // for reference tree item
      targetNodeWihtinProject = (targetNode.file_loc.project_id.indexOf(projectContext.organization + "/" + projectContext.repository) > 0);
      targetNodeWithinFile = (targetNodeWihtinProject && projectContext.dirpath === targetNode.file_loc.path)
    }

    var targetFileLocation = null;
    if (!targetNodeWithinFile) {
      targetFileLocation = targetNode.file_loc;
    }
    return {
      withinProject: targetNodeWihtinProject,
      withinFile: targetNodeWithinFile,
      // If the node is within file, this field is null,
      // Otherwise, it's {
      //   path:
      //   project_id:
      //   scm_version:
      // }
      fileLoc: targetFileLocation,
      line: targetNode.range.start_loc.line
    };
  }

  function JumpToNode(targetNode, projectContext) {
    var targetData = prepareJumpToData(targetNode, projectContext);
    if (targetData.withinFile) {
      window.location.href =
        URI(window.location.href).hash("L" + (targetData.line + 1)).toString();
    } else {
      var revision = projectContext.revision;
      if (!targetData.withinProject) {
        revision = "HEAD";  // always use HEAD by default for cross project jump.
      }
      var uri = URI(targetData.fileLoc.project_id + "/blob/" + revision + "/");
      uri.filename(targetData.fileLoc.path);
      uri.protocol("https");
      if (targetData.line > 0) {
        uri.hash("L" + (targetData.line + 1));
      }
      window.location.href = uri.toString();
    }
  }

  return {
    jumpToNode: JumpToNode
  }
});