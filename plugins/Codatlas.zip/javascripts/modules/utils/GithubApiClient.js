define(function(require) {
  var URI = require("uri/URI");
  var $ = require("jquery");

  var githubServer_ = "https://api.github.com/";

  // TODO(megnwei): Add rate limiter for github api calls.

  var loadProjectBranchs_ = function(projectContext, onSuccess, onError) {
    var uri = new URI(githubServer_);
    // Example: https://api.github.com/repos/apache/sqoop/git/refs/
    uri.segment([
      "repos",
      projectContext.organization,
      projectContext.repository,
      "git",
      "refs"
    ]);
    $.ajax({
      url: uri.toString(),
      type: "GET",
      success: onSuccess,
      error: onError
    })
  };

  var loadProjectTags_ = function(projectContext, onSuccess, onError) {
    var uri = new URI(githubServer_);
    // Example: https://api.github.com/repos/apache/sqoop/git/refs/tags
    uri.segment([
      "repos",
      projectContext.organization,
      projectContext.repository,
      "git",
      "refs",
      "tags"
    ]);
    $.ajax({
      url: uri.toString(),
      type: "GET",
      success: onSuccess,
      error: onError
    })
  };

  return {
    loadProjectBranches: loadProjectBranchs_,
    loadProjectTags: loadProjectTags_
  }
});