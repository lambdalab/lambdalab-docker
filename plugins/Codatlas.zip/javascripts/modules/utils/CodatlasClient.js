/*
 * This class is a local communication client talking directly with Codatlas server.
 */

define(function(require) {
  var URI = require("uri/URI");
  var $ = require("jquery");

  var PROJECT_DOMAIN = "github.com";

  var codatlasServer_ = function(config) {
    var uri = new URI();
    uri.protocol(config.protocol);
    uri.hostname(config.host);
    if (config.port !== undefined) {
      uri.port(config.port);
    }
    return uri;
  };

  var useBackgroundProxy = true;
  var postMessage_ = function(request) {
    if (useBackgroundProxy) {
      CodatlasProxyClient.Query(request);
    } else {
      $.ajax(request);
    }
  };

  var loadProjectInfo_ = function(projectContext, onSuccess, onError) {
    var uri = codatlasServer_(codatlasServerConfig);
    uri.segment([
      "loadProjectInfo",
      PROJECT_DOMAIN,
      projectContext.organization,
      projectContext.repository
    ]);
    postMessage_({
      url: uri.toString(),
      type: "GET",
      success: onSuccess,
      error: onError
    });
  };

  var loadMetadata_ = function(projectContext, onSuccess, onError) {
    var uri = codatlasServer_(codatlasServerConfig);
    uri.segment([
      "loadMetadata",
      PROJECT_DOMAIN,
      projectContext.organization,
      projectContext.repository,
      projectContext.revision,
      projectContext.path
    ]);
    postMessage_({
      url: uri.toString(),
      type: "GET",
      success: onSuccess,
      error: onError
    });
  };

  var loadReferences_ = function(projectContext, lambdaId, onSuccess, onError) {
    var uri = codatlasServer_(codatlasServerConfig);
    uri.segment([
      "loadReferences",
       PROJECT_DOMAIN,
       projectContext.organization,
       projectContext.repository,
       projectContext.revision,
       encodeURIComponent(lambdaId)
    ]);
    postMessage_({
      url: uri.toString(),
      type: "GET",
      success: onSuccess,
      error: onError
    });
  };

  var loadNode_ = function(projectContext, lambdaId, onSuccess, onError) {
    var uri = codatlasServer_(codatlasServerConfig);
    uri.segment([
      "getNode",
      encodeURIComponent(lambdaId)
    ]);
    uri.setSearch("currentProject", projectContext.projectId);
    uri.setSearch("currentRevision", projectContext.revision);
    postMessage_({
      url: uri.toString(),
      type: "GET",
      success: onSuccess,
      error: onError
    });
  };

  var loadFilePrimaryData_ = function(projectContext, onSuccess, onError) {
    var uri = codatlasServer_(codatlasServerConfig);
    uri.segment([
      "loadFilePrimaryData",
      projectContext.projectId,
      projectContext.revision,
      projectContext.path
    ]);
    uri.setSearch("omitContent", false);
    postMessage_({
      url: uri.toString(),
      type: "GET",
      success: onSuccess,
      error: onError
    });
  };

  return {
    loadProjectInfo: loadProjectInfo_,
    loadMetadata: loadMetadata_,
    loadReferences: loadReferences_,
    loadNode: loadNode_,
    loadFilePrimaryData: loadFilePrimaryData_
  };
});