/*
 * This class serves as the entry point of injecting github page.
 */
define(function(require) {
  var React = require('react');
  var ReactDom = require('reactdom');
  var URI = require('uri/URI');
  var CodatlasApp = require('jsx!components/CodatlasApp');
  var $ = require('jquery');
  require("./utils/slidebars");

  function apply() {
    // 1. Inject a hooker into the page to render codatlas plugin.
    $('body').append("<div id='codatlas-container'></div>");

    // 2. Render the whole codatlas plugin app.
    ReactDom.render(<CodatlasApp />,
      document.getElementById("codatlas-container"),
      function() {
        console.log("Codatlas Ready");
      }
    );
  }

  return {
    Apply : apply
  };
});
