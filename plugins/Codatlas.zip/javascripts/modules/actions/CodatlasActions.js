define(function(require) {
  var CodatlasConstants = require('../constants/CodatlasConstants');
  var ActionTypes = CodatlasConstants.ActionTypes;
  var WindowTypes = CodatlasConstants.WindowTypes;

  return {
    changeUrl: function() {
      CodatlasDispatcher.dispatch({
        type: ActionTypes.URL_CHANGED
      });
    },
    clickNode: function(lambdaId) {
      CodatlasDispatcher.dispatch({
        type: ActionTypes.NODE_CLICKED,
        id: lambdaId
      });
    },
    hoverNode: function(lambdaId) {
      CodatlasDispatcher.dispatch({
        type: ActionTypes.NODE_HOVERRED,
        id: lambdaId
      });
    },
    updateDisplayState: function() {
      CodatlasDispatcher.dispatch({
        type: ActionTypes.UPDATE_DISPLAY_STATE
      });
    },
    hideWindow: function(windowType) {
      CodatlasDispatcher.dispatch({
        type: ActionTypes.HIDE_WINDOW,
        window: windowType
      });
    },
    hideNavigationWindow: function() {
      this.hideWindow(WindowTypes.NAVIGATION_WINDOW);
    },
    hideContentWindow: function() {
      this.hideWindow(WindowTypes.CONTENT_WINDOW);
    },
    showWindow: function(windowType) {
      CodatlasDispatcher.dispatch({
        type: ActionTypes.SHOW_WINDOW,
        window: windowType
      });
    },
    showNavigationWindow: function() {
      this.showWindow(WindowTypes.NAVIGATION_WINDOW);
    },
    showContentWindow: function() {
      this.showWindow(WindowTypes.CONTENT_WINDOW);
    }
  }
});
