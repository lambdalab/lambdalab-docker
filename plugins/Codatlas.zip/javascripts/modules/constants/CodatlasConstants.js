define(function(require) {
  var MetaDataEnums = require('../genfiles/MetaDataEnum_types');

  // A helper function copied from https://github.com/STRML/keyMirror/blob/master/index.js
  var keyMirror = function(obj) {
    var ret = {};
    var key;
    if (!(obj instanceof Object && !Array.isArray(obj))) {
      throw new Error('keyMirror(...): Argument must be an object.');
    }
    for (key in obj) {
      if (!obj.hasOwnProperty(key)) {
        continue;
      }
      ret[key] = key;
    }
    return ret;
  };

  return {
    ActionTypes: keyMirror({
      URL_CHANGED: null,
      NODE_CLICKED: null,
      NODE_HOVERRED: null,
      UPDATE_DISPLAY_STATE: null,
      HIDE_WINDOW: null,
      SHOW_WINDOW: null,
      TOGGLE_DISPLAY: null
    }),
    WindowTypes: keyMirror({
      NAVIGATION_WINDOW: null,
      CONTENT_WINDOW: null
    }),
    ProjectContextStoreEvents: keyMirror({
      CONTEXT_CHANGED: null,  // ProjectInfo is not necessarily changed.
      PROJECT_INFO_CHANGED: null  // ProjectInfo is changed.
    }),
    MetaDataStoreEvents: keyMirror({
      METADATA_PROCESSED: null,  // Processed metadata ready.
      DEFINITION_NODE_REFERENCES_RETRIEVED: null,  // All references of the clicked definition node is ready.
      JUMP_TO_NODE_PROCESSED: null  // Jump to location data ready.
    }),
    FilePrimaryDataStoreEvents: keyMirror({
      FILE_PRIMARY_DATA_READY: null  // File primary data ready
    }),
    DisplayStateStoreEvents: keyMirror({
      DISPLAY_STATE_UPDATED: null
    }),
    IconClasses: {
      navigationWindowIconClass: "octicon octicon-list-unordered",
      contentWindowIconClass: "octicon octicon-git-compare"
    }
  };
});
