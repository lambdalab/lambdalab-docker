/*
 * This observer class detects whether the content of the github project
 * explorer page changes via ajax.
 */
define(function(require) {
  var observerConfig = {
    attributes: false,
    childList: true,
    characterData: true
  };

  var GITHUB_EXPLORER_UPDATE_DIV_ID = "js-repo-pjax-container";

  // For de-duplication.
  var MUTATION_DEDUPLICATION_TIMESTAMP_OFFSET_MS = 500;
  var lastPageUrl = "";
  var lastTimestamp = 0;

  /*
   * @constructor.
   */
  var apply_ = function(onMutated) {
    var target = document.querySelector("#" + GITHUB_EXPLORER_UPDATE_DIV_ID);
    var observer = new MutationObserver(function(mutations) {
      // Call mutation handler function after de-deplication.
      deDuplicateMutations_(window.location.href, Date.now(), onMutated);
    });
    observer.observe(target, observerConfig);
  };

  // Sometimes, one click can result multiple mutations, which should
  // be treated as one page refresh for us.
  var deDuplicateMutations_ = function(pageUrl, timestamp, onMutated) {
    if (pageUrl != lastPageUrl &&
        (timestamp - lastTimestamp) >= MUTATION_DEDUPLICATION_TIMESTAMP_OFFSET_MS) {
      lastPageUrl = pageUrl;
      lastTimestamp = timestamp;
      onMutated();
    }
  };

  return { apply: apply_ };
});