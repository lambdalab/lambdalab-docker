define(function(require) {
  var CodatlasConstants = require('../constants/CodatlasConstants');
  var EventEmitter = require('eventEmitter');
  var $ = require('jquery');
  var _ = require("underscore");
  var CodatlasClient = require('../utils/CodatlasClient');
  var ProjectContextStore = require('../stores/ProjectContextStore').ProjectContextStore;

  var ActionTypes = CodatlasConstants.ActionTypes;
  var FilePrimaryDataStoreEvents = CodatlasConstants.FilePrimaryDataStoreEvents;

  var FilePrimaryData_ = {};

  var FilePrimaryDataStore_ = {};
  $.extend(true, FilePrimaryDataStore_, new EventEmitter(), {
    getFilePrimaryData: function() {
      return FilePrimaryData_;
    },

    emitChange: function(eventId) {
      this.emitEvent(eventId);
    },

    addChangeListener: function(eventId, callBack) {
      this.addListener(eventId, callBack);
    },

    removeChangeListener: function(eventId, callBack) {
      this.removeListener(eventId, callBack);
    },

    dispatchToken: CodatlasDispatcher.register(function(action) {
      switch (action.type) {
        case ActionTypes.URL_CHANGED:
          CodatlasDispatcher.waitFor([ProjectContextStore.dispatchToken]);
          updateFilePrimaryData_();
          break;
        default:
          break;
      }
    })
  });

  function updateFilePrimaryData_() {;
    var projectContext = ProjectContextStore.getProjectContext();
    if (!projectContext.isFile) return;  // skip update if it's not a file page.

    CodatlasClient.loadFilePrimaryData(
      projectContext,
      // onSuccess
      function(data) {
        FilePrimaryData_.lineMapper = new LineMapper_(data.content);
        $.extend(FilePrimaryData_, data);
        FilePrimaryDataStore_.emitChange(FilePrimaryDataStoreEvents.FILE_PRIMARY_DATA_READY);
      },
      // onError
      function(error) {
        console.log("Load file primary data error.");
      }
    );
  }

  function LineMapper_(content) {
    var lines = content.split("\n");
    var acc = [0];

    for (var i = 0; i < lines.length - 1; i++) {
      acc[i + 1] = acc[i] + lines[i].length + 1
    }

    this.getRange = function (offset) {
      var line = _.sortedIndex(acc, offset);
      if (offset != acc[line]) {
        line = line - 1;
      }
      var col = offset - acc[line];
      return {line: line, column: col, offset: offset}
    }
  }

  return {
    FilePrimaryDataStore: FilePrimaryDataStore_
  }
});