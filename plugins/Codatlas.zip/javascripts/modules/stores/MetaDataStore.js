define(function(require) {
  var CodatlasConstants = require('../constants/CodatlasConstants');
  var EventEmitter = require('eventEmitter');
  var $ = require('jquery');
  var CodatlasClient = require('../utils/CodatlasClient');
  var ProjectContextStore = require('../stores/ProjectContextStore').ProjectContextStore;
  var MetaDataProcessor = require('../utils/MetadataProcessor');

  var ActionTypes = CodatlasConstants.ActionTypes;
  var MetaDataStoreEvents = CodatlasConstants.MetaDataStoreEvents;

  var processedMetaData_ = {};

  var emptyReferencesData_ = {};
  var referencesData_ = function() {
    if(typeof(window.localStorage) !== "undefined") {
      if (window.localStorage.referencesData) {
        var previousRefData = JSON.parse(window.localStorage.referencesData);
        persistReferencedData(previousRefData);
        return JSON.parse(JSON.stringify(previousRefData));
      }
      persistReferencedData(emptyReferencesData_);
      return JSON.parse(JSON.stringify(emptyReferencesData_));
    } else {
      return JSON.parse(JSON.stringify(emptyReferencesData_));
    }
  }();

  function persistReferencedData(refData) {
    if(typeof(window.localStorage) !== "undefined") {
      window.localStorage.referencesData = JSON.stringify(refData);
    }
  }

  var MetaDataStore_ = {};
  $.extend(true, MetaDataStore_, new EventEmitter(), {
    getMetaData: function() {
      return processedMetaData_;
    },

    getReferencesData: function() {
      persistReferencedData(referencesData_);
      return referencesData_;
    },

    emitChange: function(eventId) {
      this.emitEvent(eventId);
    },

    addChangeListener: function(eventId, call_back) {
      this.addListener(eventId, call_back);
    },

    removeChangeListener: function(eventId, call_back) {
      this.removeListener(eventId, call_back);
    },

    dispatchToken: CodatlasDispatcher.register(function(action) {
      switch(action.type) {
        case ActionTypes.URL_CHANGED:
          CodatlasDispatcher.waitFor([ProjectContextStore.dispatchToken]);
          updateMetaData(ProjectContextStore.getProjectContext());
          break;
        case ActionTypes.NODE_CLICKED:
          // 1. check whether we have the node cached or not.
          var node = processedMetaData_.nodesMap[action.id];
          referencesData_.clickedNode = node;
          if (node !== undefined) {
            // 2. If it exist, do node kind check.
            // TODO(mengwei): provide an util function to check Definition Node type.
            if (node.kind === NodeKind.USAGE) {
              var edges = processedMetaData_.edgesMap[action.id];
              if (edges === null || edges === undefined) {
                // This should not happen.
                console.error("Edges start with reference node " + action.id + " cannot be found.");
              } else if (edges.length > 1 ) {
                // This should not happen for a reference node.
                console.error("Edges start with reference node " + action.id + " are more than 1.");
              } else {
                updateJumpToData(ProjectContextStore.getProjectContext(), edges[0].end_id);
              }
            } else {
              updateReferences(ProjectContextStore.getProjectContext(), action.id);
            }
          } else {
            // 3. If not exist, something must be wrong.
            console.error("Clicked on non-exist node: " + action.id);
          }
          break;
        case ActionTypes.NODE_HOVERRED:
            // TODO add popover
          // referencesData_.clickedNodeId = action.id;
          // // 1. check whether we have the node cached or not.
          // var node = processedMetaData_.nodesMap[action.id];
          // if (node !== undefined) {
          //   // 2. If it exist, do node kind check.
          //   // TODO(mengwei): provide an util function to check Definition Node type.
          //   if (node.kind != NodeKind.USAGE) {
          //     updateReferences(ProjectContextStore.getProjectContext(), action.id);
          //   }
          // } else {
          //   // 3. If not exist, something must be wrong.
          //   console.error("Clicked on non-exist node: " + action.id);
          // }
          break;
        default:
          break;
      }
    })
  });

  function updateMetaData(projectContext) {
    if (!projectContext.isFile) return;  // skip update if it's not a file page.

    CodatlasClient.loadMetadata(
      projectContext,
      // onSuccess
      function(data) {
        // Digest the raw metadata.
        processedMetaData_ = MetaDataProcessor.process(data);
        MetaDataStore_.emitChange(MetaDataStoreEvents.METADATA_PROCESSED);
      },
      // onError
      function(jqXHR, textStatus, errorThrown) {
        console.log("Error loading metadata.");
      }
    );
  }

  function updateReferences(projectContext, definitionNodeId) {
    CodatlasClient.loadReferences(
      projectContext,
      definitionNodeId,
      // onSuccess
      function(data) {
        // replace the key with actual edge type string.
        function decodeReferenceEdgeType(references) {
          var EdgeKindRev = [];
          for (kindStr in EdgeKind) {
            var kindI = EdgeKind[kindStr];
            EdgeKindRev[kindI] = kindStr;
          }
          for (key in references) {
            references[EdgeKindRev[key]] = references[key];
            delete references[key];
          }
          return references;
        }
        referencesData_.references = decodeReferenceEdgeType(data.references);
        MetaDataStore_.emitChange(MetaDataStoreEvents.DEFINITION_NODE_REFERENCES_RETRIEVED);
      },
      // onError
      function(jqXHR, textStatus, errorThrown) {
        console.log("Error loading references.");
      }
    );
  }

  function updateJumpToData(projectContext, targetNodeId) {
    var endNode = null;
    if (targetNodeId in processedMetaData_.nodesMap) {
      referencesData_.jumpToNode = processedMetaData_.nodesMap[targetNodeId];
      MetaDataStore_.emitChange(MetaDataStoreEvents.JUMP_TO_NODE_PROCESSED);
    } else {
      CodatlasClient.loadNode(
        projectContext,
        targetNodeId,
        // onSuccess
        function (data) {
          endNode = data;
          processedMetaData_.nodesMap[targetNodeId] = endNode;  // update nodesMap as a cache.
          referencesData_.jumpToNode = endNode;
          MetaDataStore_.emitChange(MetaDataStoreEvents.JUMP_TO_NODE_PROCESSED);
        },
        // onError
        function (jqXHR, textStatus, errorThrown) {
          console.log("Error loading node: " + targetNodeId);
        }
      )
    }
  }

  return {
    MetaDataStore: MetaDataStore_
  }
});
