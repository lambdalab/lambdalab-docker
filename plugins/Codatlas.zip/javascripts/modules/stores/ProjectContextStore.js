define(function(require) {
  var CodatlasConstants = require('../constants/CodatlasConstants');
  var EventEmitter = require('eventEmitter');
  var $ = require('jquery');
  var _ = require("underscore");
  var S = require("string");
  var URI = require("uri/URI");
  var CodatlasClient = require("../utils/CodatlasClient");
  var GithubClient = require("../utils/GithubApiClient");

  var ActionTypes = CodatlasConstants.ActionTypes;
  var ProjectContextStoreEvents = CodatlasConstants.ProjectContextStoreEvents;

  var projectContext_ = {};

  var ProjectContextStore_ = {};
  $.extend(true, ProjectContextStore_, new EventEmitter(), {
    getProjectContext: function() {
      return projectContext_;
    },

    emitChange: function(eventId) {
      this.emitEvent(eventId);
    },

    addChangeListener: function(eventId, call_back) {
      this.addListener(eventId, call_back);
    },

    removeChangeListener: function(eventId, call_back) {
      this.removeListener(eventId, call_back);
    },

    dispatchToken: CodatlasDispatcher.register(function(action) {
      switch(action.type) {
        case ActionTypes.URL_CHANGED:
          updateProjectContext_();
          ProjectContextStore_.emitChange(ProjectContextStoreEvents.CONTEXT_CHANGED);
          break;
        default:
          break;
      }
    })
  });

  function updateProjectContext_() {
    var pageUrl = window.location.href;
    var uri = URI(pageUrl).normalize();
    var segments = uri.segment();

    projectContext_.url = uri.toString();                         // The original url that the user visits.
    projectContext_.cloneUrl = getCloneUrl_(segments);            // The clone url of current repository.
    projectContext_.organization = getOrganization_(segments);    // The organization of current repository.
    projectContext_.repository = getRepository_(segments);        // The repository's name.
    projectContext_.revision = parseRevision_(getRevision_(segments));            // The revision (branch/tag/revision).
    projectContext_.path = getRelativePath_(segments);         // Current relative path within the repository.
    projectContext_.isFile = isFile_(segments);                   // Is the relative path a file or a dir.
    projectContext_.urlParams = getUrlQueryParams_(uri.query());  // Url parameters.
    projectContext_.projectId = "github.com/" + projectContext_.organization + "/" + projectContext_.repository;

    // If the project changed:
    // 1. Reload ProjectInfo from Codatlas.
    // 2. Reload all branches/tags from Github.
    if (doesProjectChanged_()) {
      // 1. Request ProjectInfo from Codatlas server, if it is a source file view page.
      CodatlasClient.loadProjectInfo(
        projectContext_,
        // onSuccess
        function (data) {
          projectContext_.projectInfo = data;
          ProjectContextStore_.emitChange(ProjectContextStoreEvents.PROJECT_INFO_CHANGED);
        },
        // onError
        function (jqXHR, textStatus, errorThrown) {
          console.log("Error loading project info.");
        }
      );

      // 2. Request all branchs/tags from Github of this project.
      // A helper function to format response.
      var extractRefs = function(data, refPrefix) {
        return _.indexBy(
          // Find all branch refs.
          _.filter(data, function(item) {
            return S(item.ref).startsWith(refPrefix);
          }),
          // Indexed by branch's name.
          function(item) {
            return S(item.ref).chompLeft(refPrefix);
          }
        )
      };
      GithubClient.loadProjectBranches(
        projectContext_,
        // onSuccess
        function (data) {
          // Example:
          // [ "branch-1.4.4": {
          //    "ref": "refs/heads/branch-1.4.4",
          //    "url": "https://api.github.com/repos/apache/sqoop/git/refs/heads/branch-1.4.4",
          //    "object": {
          //      "sha": "050a2015514533bc25f3134a33401470ee9353ad",
          //      "type": "commit",
          //      "url": "https://api.github.com/repos/apache/sqoop/git/commits/050a2015514533bc25f3134a33401470ee9353ad"
          //    }
          //  }
          // ]
          projectContext_.branches = extractRefs(data, "refs/heads/");
          projectContext_.revision = parseRevision_(projectContext_.revision);
          ProjectContextStore_.emitChange(ProjectContextStoreEvents.CONTEXT_CHANGED);
        },
        // onError
        function (jqXHR, textStatus, errorThrown) {
          console.log("Error loading project branches.");
        }
      );
      GithubClient.loadProjectTags(
        projectContext_,
        // onSuccess
        function (data) {
          // Example:
          // [ "release-1.99.6-rc2": {
          //    "ref": "refs/tags/release-1.99.6-rc2",
          //    "url": "https://api.github.com/repos/apache/sqoop/git/refs/heads/branch-1.4.4",
          //    "object": {
          //      "sha": "050a2015514533bc25f3134a33401470ee9353ad",
          //      "type": "commit",
          //      "url": "https://api.github.com/repos/apache/sqoop/git/commits/050a2015514533bc25f3134a33401470ee9353ad"
          //    }
          //  }
          // ]
          projectContext_.tags = extractRefs(data, "refs/tags/");
          projectContext_.revision = parseRevision_(projectContext_.revision);
          ProjectContextStore_.emitChange(ProjectContextStoreEvents.CONTEXT_CHANGED);
        },
        // onError
        function (jqXHR, textStatus, errorThrown) {
          console.log("Error loading project tags.");
        }
      );
    }
  }

  // Use commit sha if possible to avoid the interpretation difference of a branch in sha
  // between Codatlas and Github.
  function parseRevision_(revision) {
    // 1. Check if it's a branch name.
    if (projectContext_.branches !== undefined &&
        projectContext_.branches[revision] !== undefined) {
      return projectContext_.branches[revision].object.sha;
    // 2. Check if it's a tag name.
    } else if (projectContext_.tags !== undefined &&
               projectContext_.tags[revision] !== undefined) {
      return projectContext_.tags[revision].object.sha;
    } else {
      // 3. fall back with the original revision string.
      return revision;
    }
  }

  // Helper function to check if project changed.
  function doesProjectChanged_() {
    return projectContext_.projectInfo === undefined ||
      (projectContext_.organization + "/" + projectContext_.repository) !==
      (projectContext_.projectInfo.owner + "/" + projectContext_.projectInfo.name);
  }

  // Helper functions for url parsing.
  function getCloneUrl_(segments) {
    var uri = new URI("https://github.com");
    uri.segment([getOrganization_(segments), (getRepository_(segments) + ".git")]);
    return uri.toString();
  }

  function getOrganization_(segments) {
    if (segments.length > 0) {
      return segments[0];
    }
    return "";
  }

  function getRepository_(segments) {
    if (segments.length > 1) {
      return segments[1];
    }
    return "";
  }

  function getRevision_(segments) {
    if (segments.length > 3) {
      return segments[3];
    }
    return "HEAD";
  }

  function getRelativePath_(segments) {
    if (segments.length > 4) {
      return segments.slice(4).join("/");
    }
    return "";
  }

  function getUrlQueryParams_(queryStr) {
    return _.object(_.map(queryStr.split("&"), function(query) {
      return query.split("=");
    }));
  }

  function isFile_(segments) {
    if (segments.length > 2) {
      return (segments[2] === "blob" || segments[2] === "blame");
    }
    return false;
  }

  return {
    ProjectContextStore: ProjectContextStore_
  };
});