define(function(require) {
  var CodatlasConstants = require('../constants/CodatlasConstants');
  var ProjectContextStore = require('../stores/ProjectContextStore').ProjectContextStore;
  var MetaDataStore = require('../stores/MetaDataStore').MetaDataStore;
  var EventEmitter = require('eventEmitter');
  var $ = require('jquery');
  var _ = require("underscore");

  var ActionTypes = CodatlasConstants.ActionTypes;
  var WindowTypes = CodatlasConstants.WindowTypes;
  var DisplayStateStoreEvents = CodatlasConstants.DisplayStateStoreEvents;

  var projectContext_ = null;
  var metadata_ = null;

  var defaultDisplayState = {
    enableNavigationButton: false,
    enableContentButton: false,
    showNavigationWindow: false,
    showContentWindow: false
  };

  function persisDisplayState(displayState) {
    if(typeof(window.localStorage) !== "undefined") {
      window.localStorage.displayState = JSON.stringify(displayState);
    }
  }

  var displayState_ = function () {
    if(typeof(window.localStorage) !== "undefined") {
      if (window.localStorage.displayState) {
          var previousState = JSON.parse(window.localStorage.displayState);
          persisDisplayState(previousState);
          return JSON.parse(JSON.stringify(previousState));
      }
      persisDisplayState(defaultDisplayState);
      return JSON.parse(JSON.stringify(defaultDisplayState));
    } else {
      return JSON.parse(JSON.stringify(defaultDisplayState));
    }
  }();

  var DisplayStateStore_ = {};
  $.extend(true, DisplayStateStore_, new EventEmitter(), {
    getDisplayState: function() {
      persisDisplayState(displayState_);
      return displayState_;
    },

    emitChange: function(eventId) {
      this.emitEvent(eventId);
    },

    addChangeListener: function(eventId, call_back) {
      this.addListener(eventId, call_back);
    },

    removeChangeListener: function(eventId, call_back) {
      this.removeListener(eventId, call_back);
    },

    dispatchToken: CodatlasDispatcher.register(function(action) {
      switch (action.type) {
        case ActionTypes.URL_CHANGED:
          CodatlasDispatcher.waitFor([
            ProjectContextStore.dispatchToken,
            MetaDataStore.dispatchToken
          ]);
          projectContext_ = ProjectContextStore.getProjectContext();
          // Hide all windows if not file
          if (!projectContext_.isFile) {
            displayState_.enableContentButton = false;
            displayState_.enableNavigationButton = false;
            displayState_.showContentWindow = false;
            displayState_.showNavigationWindow = false;
          } else {
            // Only show content window when referenceData is not empty.
            var referenceData = MetaDataStore.getReferencesData();
            var hasReferenceData =
                (referenceData !== undefined &&
                 !_.isEmpty(referenceData) &&
                 referenceData.references !== undefined &&
                 !_.isEmpty(referenceData.references));
            displayState_.showContentWindow = displayState_.showContentWindow && hasReferenceData;
            displayState_.enableContentButton = displayState_.enableContentButton && hasReferenceData;
          }
          DisplayStateStore_.emitChange(DisplayStateStoreEvents.DISPLAY_STATE_UPDATED);
          break;
        case ActionTypes.UPDATE_DISPLAY_STATE:
          metadata_ = MetaDataStore.getMetaData();
          if (metadata_.available && projectContext_.isFile) {
              // we don't show content tab and button because we don't know if it's a click
            displayState_.enableNavigationButton = true;
          } else {
            displayState_.enableContentButton = false;
            displayState_.enableNavigationButton = false;
            displayState_.showContentWindow = false;
            displayState_.showNavigationWindow = false;
          }
          DisplayStateStore_.emitChange(DisplayStateStoreEvents.DISPLAY_STATE_UPDATED);
          break;
        case ActionTypes.HIDE_WINDOW:
          if (action.window === WindowTypes.CONTENT_WINDOW && displayState_.showContentWindow) {
            displayState_.showContentWindow = false;
            DisplayStateStore_.emitChange(DisplayStateStoreEvents.DISPLAY_STATE_UPDATED);
          }
          if (action.window === WindowTypes.NAVIGATION_WINDOW && displayState_.showNavigationWindow) {
            displayState_.showNavigationWindow = false;
            DisplayStateStore_.emitChange(DisplayStateStoreEvents.DISPLAY_STATE_UPDATED);
          }
          break;
        case ActionTypes.SHOW_WINDOW:
          if (action.window === WindowTypes.CONTENT_WINDOW && !displayState_.showContentWindow) {
            displayState_.showContentWindow = true;
            DisplayStateStore_.emitChange(DisplayStateStoreEvents.DISPLAY_STATE_UPDATED);
          }
          if (action.window === WindowTypes.NAVIGATION_WINDOW && !displayState_.showNavigationWindow) {
            displayState_.showNavigationWindow = true;
            DisplayStateStore_.emitChange(DisplayStateStoreEvents.DISPLAY_STATE_UPDATED);
          }
          break;
        case ActionTypes.NODE_CLICKED:
          CodatlasDispatcher.waitFor([MetaDataStore.dispatchToken]);
          var metadata = MetaDataStore.getMetaData();
          var node = metadata.nodesMap[action.id];
          if (node !== undefined && node.kind !== NodeKind.USAGE) {
            displayState_.showContentWindow = true;
            displayState_.enableContentButton = true;
            DisplayStateStore_.emitChange(DisplayStateStoreEvents.DISPLAY_STATE_UPDATED);
          }
          break;
        default:
          break;
      }
    })
  });

  return {
    DisplayStateStore: DisplayStateStore_
  };
});
