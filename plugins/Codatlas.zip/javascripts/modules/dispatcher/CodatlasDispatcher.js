var Dispatcher = require('../../../../node_modules/flux').Dispatcher;
var CodatlasDispatcher = new Dispatcher();

module.exports = CodatlasDispatcher;