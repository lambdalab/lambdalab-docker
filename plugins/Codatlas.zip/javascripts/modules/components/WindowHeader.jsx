define([
  '../constants/CodatlasConstants',
  '../actions/CodatlasActions',
  'react'
], function(
  CodatlasConstants,
  CodatlasActions,
  React
) {
  var IconClasses = CodatlasConstants.IconClasses;
  var WindowTypes = CodatlasConstants.WindowTypes;
  return React.createClass({
    render: function() {
      var iconClass = this.getHeaderIconClass_(this.props.windowType);
      var buttonClickActions = this.updateControlButtonClickAction_();
      return (
        <div className="ca-window-header">
          <span className={iconClass}></span> {this.props.title}
          <div className="ca-window-header-actions">
            <span className="octicon octicon-x" onClick={this.closeWindow_}></span>
          </div>
          {(() => {
            switch (this.props.windowType) {
              case "CONTENT_WINDOW":
                return <span className="btn btn-sm ca-control-button ca-close-content-window" onClick={buttonClickActions.contentButtonClickAction}>X</span>;
              default:
                return <span />;
            }
          })()}
        </div>
      );
    },

    closeWindow_: function() {
      CodatlasActions.hideWindow(this.props.windowType);
    },

    updateControlButtonClickAction_: function() {
      var buttonClickActions = {
        contentButtonClickAction: function(){}
      };
      buttonClickActions.contentButtonClickAction = this.handleContentButtonClick_
      return buttonClickActions;
    },

    handleContentButtonClick_: function() {
      CodatlasActions.hideContentWindow();
    },

    getHeaderIconClass_: function(windowType) {
      switch (windowType) {
        case WindowTypes.NAVIGATION_WINDOW:
          return IconClasses.navigationWindowIconClass;
        case WindowTypes.CONTENT_WINDOW:
          return IconClasses.contentWindowIconClass;
        default:
          return "";
      }
    }
  });
});
