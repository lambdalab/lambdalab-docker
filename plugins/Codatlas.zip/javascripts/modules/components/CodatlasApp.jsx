define([
  'jsx!components/NavigationWindow',
  'jsx!components/ContentWindow',
  'jsx!components/ControlPanel',
  '../stores/MetaDataStore',
  '../stores/ProjectContextStore',
  '../stores/DisplayStateStore',
  '../actions/CodatlasActions',
  '../constants/CodatlasConstants',
  '../utils/GithubPageRedirector',
  "interact",
  "react",
  "jquery",
  "jquerycookie"
], function(
  NavigationWindow,
  ContentWindow,
  ControlPanel,
  MetaDataStore,
  ProjectContextStore,
  DisplayStateStore,
  CodatlasActions,
  CodatlasConstants,
  GithubPageRedirector,
  Interact,
  React,
  $
) {
  var MetaDataStoreEvents = CodatlasConstants.MetaDataStoreEvents;

  return React.createClass({
    componentDidMount: function() {

      MetaDataStore.MetaDataStore.addChangeListener(
        MetaDataStoreEvents.JUMP_TO_NODE_PROCESSED,
        this.onJumpToDataProcessed_);

      // FIXME this does not work with current css
      //this.startIntro_();
    },

    componentWillUnmount: function() {
      MetaDataStore.MetaDataStore.removeChangeListener(
        MetaDataStoreEvents.JUMP_TO_NODE_PROCESSED,
        this.onJumpToDataProcessed_);
    },

    render: function() {
      return (
        <div>
          <NavigationWindow />
          <ContentWindow />
          <ControlPanel />
        </div>
      );
    },

    onJumpToDataProcessed_: function() {
      var referencesData = MetaDataStore.MetaDataStore.getReferencesData();
      var projectContext = ProjectContextStore.ProjectContextStore.getProjectContext();
      GithubPageRedirector.jumpToNode(referencesData.jumpToNode, projectContext);
    },

    startIntro_: function() {
      var displayState = DisplayStateStore.DisplayStateStore.getDisplayState();
      var sampleUrl = "https://github.com/apache/sqoop/blob/trunk/src/java/org/apache/sqoop/Sqoop.java";
      var intro = introJs();
      // $.removeCookie("codatlas-demo");  // uncomment this line for debug.
      if (window.localStorage.demo === undefined) {
        intro.setOptions({
          steps: [
            {
              intro: "Welcome to Github, boosted by <a href='https://www.codatlas.com'>Codatlas</a>.<br />" +
              "Click <strong>Start Demo</strong> below" +
              " to understand how Codatlas could help you improve your code browsing experience in Github."
            }
          ],
          doneLabel: 'Start Demo'
        });
        intro.start().oncomplete(function () {
          window.localStorage.demo = "in-progress";
          window.location.href = sampleUrl;
        });
      } else if (window.localStorage.demo === "in-progress" &&
                 window.location.href === sampleUrl) {
        intro.setOptions({
          steps: [
            {
              element: "#codatlas-control-panel-intro",
              intro: "Tthis control panel can control the toggle the display of navigation/content window.",
              position: "right"
            },
            {
              element: "#codatlas-navigation-window-intro",
              intro: "This window shows all the structure of this file. Click on each to go to the definition line. Drag and drop this window to anywhere.",
              position: "right"
            },
            {
              element: "#codatlas-content-window-intro",
              intro: "This window shows all the usages after you click on a definition in the source code. Drag and drop this window to anywhere.",
              position: "left"
            }
          ]
        });
        intro.start().oncomplete(function () {
          window.localStorage.demo = "done";
        });
      }
    }
  });
});
