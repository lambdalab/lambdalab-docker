define([
  '../stores/ProjectContextStore',
  '../stores/MetaDataStore',
  '../stores/DisplayStateStore',
  '../stores/FilePrimaryDataStore',
  '../constants/CodatlasConstants',
  '../utils/SourcePageDecorator',
  'jsx!../components/ContentTab',
  'jsx!../components/WindowHeader',
  'react',
  "../actions/CodatlasActions",
  "../genfiles/MetaDataEnum_types",
  'jquery',
  'jqueryui',
  'jstree'

], function(
  ProjectContextStore,
  MetaDataStore,
  DisplayStateStore,
  FilePrimaryDataStore,
  CodatlasConstants,
  SourcePageDecorator,
  ContentTab,
  WindowHeader,
  React,
  CodatlasActions,
  MetaDataEnum,
  $

) {
  var ProjectContextStoreEvents = CodatlasConstants.ProjectContextStoreEvents;
  var MetaDataStoreEvents = CodatlasConstants.MetaDataStoreEvents;
  var FilePrimaryDataStoreEvents = CodatlasConstants.FilePrimaryDataStoreEvents;
  var DisplayStateStoreEvents = CodatlasConstants.DisplayStateStoreEvents;

  function getStateFromStores() {
    return {
      metadata: MetaDataStore.MetaDataStore.getMetaData(),
      metadataReady: false,
      filedata: FilePrimaryDataStore.FilePrimaryDataStore.getFilePrimaryData(),
      filedataReady: false,
      projectContext: ProjectContextStore.ProjectContextStore.getProjectContext(),
      referencesData: MetaDataStore.MetaDataStore.getReferencesData()
    }
  }

  return React.createClass({
    getInitialState: function() {
      return getStateFromStores();
    },

    componentDidMount: function() {
      $("#codatlas-content-window").hide();

      ProjectContextStore.ProjectContextStore.addChangeListener(
        ProjectContextStoreEvents.CONTEXT_CHANGED,
        this.onProjectContextChanged_);
      ProjectContextStore.ProjectContextStore.addChangeListener(
        ProjectContextStoreEvents.PROJECT_INFO_CHANGED,
        this.onProjectInfoChanged_);
      MetaDataStore.MetaDataStore.addChangeListener(
        MetaDataStoreEvents.METADATA_PROCESSED,
        this.onMetaDataProcessed_);
      MetaDataStore.MetaDataStore.addChangeListener(
        MetaDataStoreEvents.DEFINITION_NODE_REFERENCES_RETRIEVED,
        this.onReferencesRetrieved_);
      FilePrimaryDataStore.FilePrimaryDataStore.addChangeListener(
        FilePrimaryDataStoreEvents.FILE_PRIMARY_DATA_READY,
        this.onFilePrimaryDataReady_);
      DisplayStateStore.DisplayStateStore.addChangeListener(
        DisplayStateStoreEvents.DISPLAY_STATE_UPDATED,
        this.onDisplayStateUpdated_);
    },

    componentWillUnmount: function() {
      ProjectContextStore.ProjectContextStore.removeChangeListener(
        ProjectContextStoreEvents.CONTEXT_CHANGED,
        this.onProjectContextChanged_);
      ProjectContextStore.ProjectContextStore.removeChangeListener(
        ProjectContextStoreEvents.PROJECT_INFO_CHANGED,
        this.onProjectInfoChanged_);
      MetaDataStore.MetaDataStore.removeChangeListener(
        MetaDataStoreEvents.METADATA_PROCESSED,
        this.onMetaDataProcessed_);
      MetaDataStore.MetaDataStore.removeChangeListener(
        MetaDataStoreEvents.DEFINITION_NODE_REFERENCES_RETRIEVED,
        this.onReferencesRetrieved_);
      FilePrimaryDataStore.FilePrimaryDataStore.removeChangeListener(
        FilePrimaryDataStoreEvents.FILE_PRIMARY_DATA_READY,
        this.onFilePrimaryDataReady_);
      DisplayStateStore.DisplayStateStore.removeChangeListener(
        DisplayStateStoreEvents.DISPLAY_STATE_UPDATED,
        this.onDisplayStateUpdated_);
    },

    render: function() {
      var windowTitle = "References";
      if (this.state.referencesData !== undefined && this.state.referencesData.clickedNode !== undefined) {
        windowTitle = "References for " + this.state.referencesData.clickedNode.display;
      }
      return (
        <div id="codatlas-content-window" className="ca-content-window">
          <div id="codatlas-content-window-intro" className="ca-window-inner">
            <WindowHeader windowType={CodatlasConstants.WindowTypes.CONTENT_WINDOW} title={windowTitle} />
            <div className="ca-content-container">
              <ContentTab references={this.state.referencesData.references} context={this.state.projectContext}/>
            </div>
          </div>
        </div>
      );
    },

    onProjectContextChanged_: function() {
      this.setState({
        projectContext: ProjectContextStore.ProjectContextStore.getProjectContext()
      });
    },

    onProjectInfoChanged_: function() {
      this.setState({
        projectContext: ProjectContextStore.ProjectContextStore.getProjectContext()
      });
    },

    onFilePrimaryDataReady_: function() {
      this.setState({
        filedata: FilePrimaryDataStore.FilePrimaryDataStore.getFilePrimaryData(),
        filedataReady: true
      });
      this.tryAnnotateSpan_();
    },

    onMetaDataProcessed_: function() {
      this.setState({
        metadata: MetaDataStore.MetaDataStore.getMetaData(),
        metadataReady: true
      });
      this.tryAnnotateSpan_();
    },

    onReferencesRetrieved_: function() {
      this.setState({
        referencesData: MetaDataStore.MetaDataStore.getReferencesData()
      });
      var displayState = DisplayStateStore.DisplayStateStore.getDisplayState();
      if (displayState.showContentWindow) {
        // only open this window when user opens it
        CodatlasActions.showWindow(CodatlasConstants.WindowTypes.CONTENT_WINDOW);
      }
    },

    onDisplayStateUpdated_: function() {
      var displayState = DisplayStateStore.DisplayStateStore.getDisplayState();
      if (displayState.showContentWindow) {
        $("#codatlas-content-window").show();
      } else {
        $("#codatlas-content-window").hide();
      }
    },

    tryAnnotateSpan_: function() {
      if (!this.state.metadataReady || !this.state.filedataReady) return;

      // @const
      var GITHUB_LINE_SELECTOR_ID_PREFIX = "LC";

      var CODATLAS_USAGE_NODE_CLASSNAME = "ca-usage";
      var CODATLAS_DEFINITION_NODE_CLASSNAME = "ca-definition";

      var parseNodeClassName_ = function(kind) {
        if (kind == NodeKind.USAGE) return CODATLAS_USAGE_NODE_CLASSNAME;
        else return CODATLAS_DEFINITION_NODE_CLASSNAME;
      };

      var decorateLine_ = function (nodes, line, lineMapper) {
        var lineDomTree = $(getLineSelector_(line))[0];
        for(var i = 0; i < nodes.length; ++i) {
          var node = nodes[i];
          var onClick = function(curNode) {
            return function() {
              CodatlasActions.clickNode(curNode.signature);
            };
          };
          var onHover = function(curNode) {
            return function() {
              CodatlasActions.hoverNode(curNode.signature);
            };
          };

          SourcePageDecorator.addSpanToDomTreeByLine(
            lineDomTree,
            node,
            parseNodeClassName_(node.kind),
            {click: onClick(node), mouseover: onHover(node)},
            lineMapper
          );
        }
      };

      var getLineSelector_ = function(line) {
        return "#" + GITHUB_LINE_SELECTOR_ID_PREFIX + line;
      };

      var processedMetadata = this.state.metadata;

      for (var line in processedMetadata.nodesByLine) {
        decorateLine_(processedMetadata.nodesByLine[line], parseInt(line) + 1, this.state.filedata.lineMapper);  // Github line start from 1.
      }
    }
  });
});
