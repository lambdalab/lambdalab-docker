define(['react'], function(React) {
  return React.createClass({
    render: function() {
      return (
        <div>
          <span className="deftree-lineno">{this.props.lineno}:</span>
          <span className="deftree-content" dangerouslySetInnerHTML={{__html: this.props.lineContent}}></span>
        </div>
      );
    }
  });
});