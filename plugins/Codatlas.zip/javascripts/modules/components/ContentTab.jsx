define([
  'react',
  'jsx!../components/ReferenceTree',
  'underscore',
  'jquery',
  'jqueryui',
  'jstree'
], function(
  React,
  ReferenceTree,
  _,
  $
) {
  return React.createClass({
    componentDidMount: function() {
      $('#content-tabs').tabs();  // Initialization.
    },

    componentDidUpdate: function() {
      $('#content-tabs').tabs("destroy");
      $('#content-tabs').tabs().addClass('ui-helper-clearfix');
    },

    render: function() {
      var projectContext = this.props.context;
      function capitalizeFirstLetter(string) {
          return string[0].toUpperCase() + string.slice(1).toLowerCase();
      }
      return (
        <div id="content-tabs">
          <ul>
          {_.map(this.props.references, function(references /* value */, refType /* key */) {
            return <li><a href={"#Tree" + refType}>{capitalizeFirstLetter(refType)}</a></li>
          })}
          </ul>
          {_.map(this.props.references, function(references /* value */, refType /* key */) {
            return <ReferenceTree tabTitle={refType} references={references}  context={projectContext}/>
          })}
        </div>
      );
    }
  });
});
