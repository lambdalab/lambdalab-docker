define([
  '../utils/GithubPageRedirector',
  'jsx!../components/DefinitionTreeLeaf',
  'react',
  'reactdomserver',
  'underscore',
  'jquery',
  'jstree'
], function(
  GithubPageRedirector,
  DefinitionTreeLeaf,
  React,
  ReactDomServer,
  _,
  $
) {
  var $referenceTree;

  return React.createClass({
    componentDidMount: function() {
      this.renderReferenceTree_();
    },

    componentDidUpdate: function() {
      this.renderReferenceTree_();
    },

    render: function() {
      return (
        <div id={"Tree" + this.props.tabTitle} className="tree-container"></div>
      );
    },

    renderReferenceTree_: function() {
      var projectContext = this.props.context;
      $referenceTree = $("#Tree" + this.props.tabTitle);
      $referenceTree.jstree();
      $referenceTree.jstree().destroy();
      $referenceTree.addClass("deftree");
      $referenceTree.jstree({
        "plugins": [ "wholerow" ],
        "core": {
          "themes": { "icons": false },
          "animation": 100,
          "data": _.map(this.props.references, this.buildProjectLevel_)
        }
      });
      $referenceTree.on('activate_node.jstree', function (e, data) {
        var $tree = data.instance;
        var node = data.node;
        if ($tree.is_leaf(node)) {
          var pnode = $tree.get_node(node.parent).original;
          // Create a dummy node as the jumping target.
          var targetNode = {
            file_loc: pnode.file_loc,
            range: {
              start_loc: {
                line: node.original.lineno
              }
            }
          };
          GithubPageRedirector.jumpToNode(targetNode, projectContext);
        }
      });
    },

    buildProjectLevel_: function(references) {
      var info = references.project_info;

      var refInProject = {};
      refInProject.text = '<span class="deftree-path"><strong>' + info.owner + "/" + info.name + '</strong></span>';
      refInProject.children = _.map(references.references, function(refInFile) {
        refInFile.text = '<span class="deftree-path">' + refInFile.file_loc.path + '</span>';
        refInFile.children = $.each(refInFile.references, function(k, refInLine) {
          var content = refInLine.content;
          var contentHtml = "";

          var previousEnd = 0;
          for (var i = 0; i < refInLine.ranges.length; i++) {
            var loc = refInLine.ranges[i];
            contentHtml += content.substring(previousEnd, loc.start_offset);
            contentHtml += "<strong>" + content.substring(loc.start_offset, loc.end_offset) + "</strong>";
            previousEnd = loc.end_offset;
          }
          contentHtml += content.substring(previousEnd);

          // TODO: remove this 'renderToString' function.
          var html = ReactDomServer.renderToString(
            <DefinitionTreeLeaf lineno={refInLine.lineno + 1} lineContent={contentHtml} />);
          refInLine.text = html;
          return refInLine;
        });
        refInFile.state = { opened: true };
        //refInFile.state = { opened: true };
        return refInFile;
      });
      refInProject.state = { opened: true };
      return refInProject;
    }
  });
});