define([
  '../actions/CodatlasActions',
  '../stores/MetaDataStore',
  '../stores/DisplayStateStore',
  '../constants/CodatlasConstants',
  'react'
], function(
  CodatlasActions,
  MetaDataStore,
  DisplayStateStore,
  CodatlasConstants,
  React
) {
  var MetaDataStoreEvents = CodatlasConstants.MetaDataStoreEvents;
  var DisplayStateStoreEvents = CodatlasConstants.DisplayStateStoreEvents;

  function getStateFromStores() {
    return {
      displayState: DisplayStateStore.DisplayStateStore.getDisplayState()
    }
  }

  return React.createClass({
    getInitialState: function() {
      return getStateFromStores();
    },

    componentDidMount: function() {
      MetaDataStore.MetaDataStore.addChangeListener(
        MetaDataStoreEvents.METADATA_PROCESSED,
        this.onMetaDataProcessed_);
      DisplayStateStore.DisplayStateStore.addChangeListener(
        DisplayStateStoreEvents.DISPLAY_STATE_UPDATED,
        this.onDisplayStateUpdated_);
    },

    componentWillUnmount: function() {
      MetaDataStore.MetaDataStore.removeChangeListener(
        MetaDataStoreEvents.METADATA_PROCESSED,
        this.onMetaDataProcessed_);
      DisplayStateStore.DisplayStateStore.removeChangeListener(
        DisplayStateStoreEvents.DISPLAY_STATE_UPDATED,
        this.onDisplayStateUpdated_);
    },

    render: function() {
      var buttonClasses = this.updateControlButtonClass_();
      var buttonClickActions = this.updateControlButtonClickAction_();
      return (
        <div id="codatlas-control-panel" className="ca-control-panel" >
          <div id="codatlas-control-panel-intro">
            <span id="codatlas-nav-control-button" className={"btn btn-sm ca-control-button " + buttonClasses.navigationButtonClass} onClick={buttonClickActions.navigationButtonClickAction} >
              <span className={CodatlasConstants.IconClasses.navigationWindowIconClass}></span> Navigation
            </span>
          </div>
        </div>
      );
    },

    updateControlButtonClass_: function() {
      var buttonClasses = {
        navigationButtonClass: "btn-default",
        contentButtonClass: "btn-default"
      };
      // check show/hide state
      if (!this.state.displayState.showNavigationWindow) {
        buttonClasses.navigationButtonClass = "btn-primary"
      }
      if (!this.state.displayState.showContentWindow) {
        buttonClasses.contentButtonClass = "btn-primary"
      }

      return buttonClasses;
    },

    updateControlButtonClickAction_: function() {
      var buttonClickActions = {
        navigationButtonClickAction: function(){},
        contentButtonClickAction: function(){}
      };
      buttonClickActions.navigationButtonClickAction = this.handleNavigationButtonClick_
      buttonClickActions.contentButtonClickAction = this.handleContentButtonClick_
      return buttonClickActions;
    },

    onDisplayStateUpdated_: function() {
      var displayState = DisplayStateStore.DisplayStateStore.getDisplayState();
      this.setState({
        displayState: displayState
      });
    },

    onMetaDataProcessed_: function() {
      CodatlasActions.updateDisplayState();
    },

    handleNavigationButtonClick_: function() {
      if (this.state.displayState.showNavigationWindow) {
        CodatlasActions.hideNavigationWindow();
      } else {
        CodatlasActions.showNavigationWindow();
      }
    },

    handleContentButtonClick_: function() {
      if (this.state.displayState.showContentWindow) {
        CodatlasActions.hideContentWindow();
      } else {
        CodatlasActions.showContentWindow();
      }
    }
  });
});
