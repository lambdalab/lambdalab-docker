define([
  '../stores/ProjectContextStore',
  '../stores/MetaDataStore',
  '../stores/DisplayStateStore',
  '../constants/CodatlasConstants',
  'jsx!../components/StructureTree',
  'jsx!../components/WindowHeader',
  'react'
], function(
  ProjectContextStore,
  MetaDataStore,
  DisplayStateStore,
  CodatlasConstants,
  StructureTree,
  WindowHeader,
  React
) {
  var ProjectContextStoreEvents = CodatlasConstants.ProjectContextStoreEvents;
  var MetaDataStoreEvents = CodatlasConstants.MetaDataStoreEvents;
  var DisplayStateStoreEvents = CodatlasConstants.DisplayStateStoreEvents;

  function getStateFromStores() {
    return {
      metadata: MetaDataStore.MetaDataStore.getMetaData(),
      projectContext: ProjectContextStore.ProjectContextStore.getProjectContext()
    }
  }

  return React.createClass({
    getInitialState: function() {
      return getStateFromStores();
    },

    componentDidMount: function() {
      $("#codatlas-navigation-window").hide();
      ProjectContextStore.ProjectContextStore.addChangeListener(
        ProjectContextStoreEvents.CONTEXT_CHANGED,
        this.onProjectContextChanged_);
      MetaDataStore.MetaDataStore.addChangeListener(
        MetaDataStoreEvents.METADATA_PROCESSED,
        this.onMetaDataProcessed_);
      DisplayStateStore.DisplayStateStore.addChangeListener(
        DisplayStateStoreEvents.DISPLAY_STATE_UPDATED,
        this.onDisplayStateUpdated_);
    },

    componentWillUnmount: function() {
      ProjectContextStore.ProjectContextStore.removeChangeListener(
        ProjectContextStoreEvents.CONTEXT_CHANGED,
        this.onProjectContextChanged_);
      MetaDataStore.MetaDataStore.removeChangeListener(
        MetaDataStoreEvents.METADATA_PROCESSED,
        this.onMetaDataProcessed_);
      DisplayStateStore.DisplayStateStore.removeChangeListener(
        DisplayStateStoreEvents.DISPLAY_STATE_UPDATED,
        this.onDisplayStateUpdated_);
    },

    render: function() {
      return (
        <div id="codatlas-navigation-window" className="ca-navigation-window">
          <div id="codatlas-navigation-window-intro" className="ca-window-inner">
            <WindowHeader title="Structure" windowType={CodatlasConstants.WindowTypes.NAVIGATION_WINDOW} />
            <StructureTree structure={this.state.metadata.outline} context={this.state.projectContext}/>
          </div>
        </div>
      );
    },

    onProjectContextChanged_: function() {
      this.setState({
        projectContext: ProjectContextStore.ProjectContextStore.getProjectContext()
      });
    },

    onMetaDataProcessed_: function() {
      this.setState({
        metadata: MetaDataStore.MetaDataStore.getMetaData()
      });
    },

    onDisplayStateUpdated_: function() {
      var slideBarActive_ = function() {
        //TODO: why sometimes active is not a function?
        return $.slidebars && $.slidebars.active;
      }
      var displayState = DisplayStateStore.DisplayStateStore.getDisplayState();
      if (displayState.showNavigationWindow) {
        if (slideBarActive_() && !$.slidebars.active('left')) {
          $.slidebars.open('left');
        }
        $("#codatlas-navigation-window").show();
      } else {
        if (slideBarActive_() && $.slidebars.active('left')) {
          $.slidebars.close();
        }
        $("#codatlas-navigation-window").hide();
      }
    }
  });
});
