define([
  '../utils/GithubPageRedirector',
  'react',
  'uri/URI',
  'jquery',
  'jstree'
], function(
  GithubPageRedirector,
  React,
  URI,
  $
) {
  var structureTreeDivId = "structure";
  var $structureTree;

  return React.createClass({
    componentDidMount: function() {
      this.renderStructureTree_();
    },

    componentDidUpdate: function() {
      this.renderStructureTree_();
    },

    render: function() {
      return (
        <div id={structureTreeDivId} className="tree-container ca-navigation-container"></div>
      );
    },

    renderStructureTree_: function() {
      var getIconUrl = function(iconUrl) {
        return chrome.extension.getURL("images/" + iconUrl);
      };

      if (this.props.structure === undefined) return;

      var projectContext = this.props.context;
      $structureTree = $("#" + structureTreeDivId);
      $structureTree.jstree();
      $structureTree.jstree().destroy();
      $structureTree.addClass("deftree");
      $structureTree.jstree({
        "core" : {
          "annimation": 100,
          "data" : this.props.structure.children
        },
        "checkbox" : {
          "keep_selected_style" : false
        },
        "plugins" : [ "wholerow", "types" ],
        "types": {
          "default": {
            "icon": getIconUrl("xml_element.png")
          },
          "0": {
            "icon": getIconUrl("iconPackage.png")
          },
          "2": {
            "icon": getIconUrl("classTypeJavaClass.png")
          },
          "3": {
            "icon": getIconUrl("classTypeInterface.png")
          },
          "4": {
            "icon": getIconUrl("variable.png")
          },
          "5": {
            "icon": getIconUrl("field.png")
          },
          "7": {
            "icon": getIconUrl("method.png")
          },
          "10": {
            "icon": getIconUrl("classTypeAnnot.png")
          },
          "12": {
            "icon": getIconUrl("classTypeAnnot.png")
          },
          "13": {
            "icon": getIconUrl("method.png")
          }
        }
      });
      $structureTree.on('activate_node.jstree', function (e, data) {
        GithubPageRedirector.jumpToNode(data.node.original.node, projectContext);
      });
    }
  });
});