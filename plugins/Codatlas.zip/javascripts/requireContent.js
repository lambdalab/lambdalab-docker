// This script loads the js modules in chrome extension instead of the content page.
// Reference: http://prezi.com/rodnyr5awftr/requirejs-in-chrome-extensions/
require.load = function(context, moduleName, url) {
  // change the url to load jsx from chrome extension
  if (url.lastIndexOf("chrome-extension://", 0) !== 0) {
    url = chrome.extension.getURL(url);
  }
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url + "?r=" + (new Date()).getTime(), true);
  xhr.onreadystatechange = function(e) {
    if (xhr.readyState === 4 && xhr.status === 200) {
      eval(xhr.responseText);
      context.completeLoad(moduleName);
    }
  };
  xhr.send(null);
};